#!/bin/bash
instance=$1

# variables used for returning the status of the scripts
success=0
error=1
warning=2

retVal=$success
exit $retVal

